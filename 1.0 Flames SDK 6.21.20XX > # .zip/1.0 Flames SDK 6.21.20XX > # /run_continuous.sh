#!/bin/bash

./run.sh --continuous $@
